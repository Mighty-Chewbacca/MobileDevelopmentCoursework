/** Automatically generated file. DO NOT MODIFY */
package org.me.myandroidstuff;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}